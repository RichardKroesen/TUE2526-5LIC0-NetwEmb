#include "SimpleLoRaSensorApp.h"
#include "inet/mobility/static/StationaryMobility.h"
#include "../LoRa/LoRaTagInfo_m.h"
#include "inet/common/packet/Packet.h"
#include <cmath>

namespace flora {

Define_Module(SimpleLoRaSensorApp);

// --- Bitmask constants ---
constexpr int SB_NONE        = 0;
constexpr int SB_TEMPERATURE = 1 << 0;
constexpr int SB_NO2         = 1 << 1;
constexpr int SB_HUMIDITY    = 1 << 2;
constexpr int SB_COUNTER     = 1 << 3;

void SimpleLoRaSensorApp::initialize(int stage)
{
    cSimpleModule::initialize(stage);
    if (stage == INITSTAGE_LOCAL) {
        jitterFrac = par("intervalJitterFraction").doubleValue();
        baseTemp   = par("baseTemperature").doubleValue();
        ampTemp    = par("amplitudeTemperature").doubleValue();
        baseHum    = par("baseHumidity").doubleValue();
        ampHum     = par("amplitudeHumidity").doubleValue();
        baseNO2    = par("baseNO2").doubleValue();
        ampNO2     = par("amplitudeNO2").doubleValue();
        basePayloadBytes = par("basePayloadBytes").intValue();

        // Initialize sensors
        initSensor(SID_TEMPERATURE, par("temperatureInterval").doubleValue(), false);
        initSensor(SID_HUMIDITY, par("humidityInterval").doubleValue(), false);
        initSensor(SID_NO2, par("no2Interval").doubleValue(), false);
        initSensor(SID_COUNTER, par("counterInterval").doubleValue(), true);

        scheduler = new cMessage("sensorScheduler");

        sigTemp    = registerSignal("temperature");
        sigHum     = registerSignal("humidity");
        sigNO2     = registerSignal("no2");
        sigCounter = registerSignal("counter");
        sigSF      = registerSignal("SF");
        sigTP      = registerSignal("TP");

        // ADR variables
        ADR_ACK_CNT = 0;
        sendNextPacketWithADRACKReq = false;
        ADR_ACK_LIMIT = 32;
        ADR_ACK_DELAY = 16;
    }
    else if (stage == INITSTAGE_APPLICATION_LAYER) {
        NodeStatus *nodeStatus = dynamic_cast<NodeStatus *>(findContainingNode(this)->getSubmodule("status"));
        bool isOperational = (!nodeStatus) || nodeStatus->getState() == NodeStatus::UP;
        if (!isOperational)
            throw cRuntimeError("Module cannot start in node DOWN state");

        sendMeasurements = new cMessage("sendMeasurements");
        scheduleAt(simTime() + par("timeToFirstPacket").doubleValue(), sendMeasurements);

        sentPackets = 0;
        receivedADRCommands = 0;
        numberOfPacketsToSend = par("numberOfPacketsToSend");

        LoRa_AppPacketSent = registerSignal("LoRa_AppPacketSent");

        loRaRadio = check_and_cast<LoRaRadio *>(getParentModule()->getSubmodule("LoRaNic")->getSubmodule("radio"));
        loRaRadio->loRaTP = par("initialLoRaTP").doubleValue();
        loRaRadio->loRaCF = units::values::Hz(par("initialLoRaCF").doubleValue());
        loRaRadio->loRaSF = par("initialLoRaSF");
        loRaRadio->loRaBW = units::values::Hz(par("initialLoRaBW").doubleValue());
        loRaRadio->loRaCR = par("initialLoRaCR");
        loRaRadio->loRaUseHeader = par("initialUseHeader");
        evaluateADRinNode = par("evaluateADRinNode");

        sfVector.setName("SF Vector");
        tpVector.setName("TP Vector");
    }
}

void SimpleLoRaSensorApp::initSensor(SensorID id, double interval, bool countOnly)
{
    Sensor s;
    s.id = id;
    s.interval = interval;
    s.counter = 0;
    s.nextDue = simTime() + uniform(0, interval);
    s.countOnly = countOnly;
    sensors.push_back(s);
}

void SimpleLoRaSensorApp::handleMessage(cMessage *msg)
{
    if (msg->isSelfMessage()) {
        if (msg == sendMeasurements) {
            sampleAndSendIfDue();
            delete msg;
            sendMeasurements = new cMessage("sendMeasurements");
            scheduleAt(simTime() + par("timeToNextPacket").doubleValue(), sendMeasurements);
        }
    } else {
        handleMessageFromLowerLayer(msg);
        delete msg;
    }
}

void SimpleLoRaSensorApp::handleMessageFromLowerLayer(cMessage *msg)
{
    auto pkt = check_and_cast<Packet *>(msg);
    const auto &packet = pkt->peekAtFront<LoRaAppPacket>();

    if (simTime() >= getSimulation()->getWarmupPeriod())
        receivedADRCommands++;

    if (evaluateADRinNode) {
        if (packet->getMsgType() == TXCONFIG) {
            if (packet->getOptions().getLoRaTP() != -1)
                setTP(packet->getOptions().getLoRaTP());
            if (packet->getOptions().getLoRaSF() != -1)
                setSF(packet->getOptions().getLoRaSF());
            EV << "Updated TP=" << getTP() << ", SF=" << getSF() << endl;
        }
    }
}

void SimpleLoRaSensorApp::sampleAndSendIfDue()
{
    int bitmap = SB_NONE;
    double temperature = NAN;
    double humidity = NAN;
    double no2 = NAN;
    long counterVal = 0;

    for (auto &s : sensors) {
        if (s.nextDue <= simTime()) {
            switch (s.id) {
                case SID_TEMPERATURE: temperature = genTemperature(); emit(sigTemp, temperature); bitmap |= SB_TEMPERATURE; break;
                case SID_HUMIDITY:    humidity = genHumidity(); emit(sigHum, humidity); bitmap |= SB_HUMIDITY; break;
                case SID_NO2:         no2 = genNO2(); emit(sigNO2, no2); bitmap |= SB_NO2; break;
                case SID_COUNTER:     s.counter++; counterVal = s.counter; emit(sigCounter, (long)counterVal); bitmap |= SB_COUNTER; break;
                default: break;
            }
            s.nextDue = simTime() + s.interval;
        }
    }

    if (bitmap == SB_NONE) return;

    auto pkt = new Packet("DataFrame");
    pkt->setKind(DATA);
    auto payload = makeShared<LoRaAppPacket>();
    payload->setChunkLength(B(par("dataSize").intValue()));

    // Request ADR ACK if needed
    if (evaluateADRinNode && sendNextPacketWithADRACKReq) {
        auto opt = payload->getOptions();
        opt.setADRACKReq(true);
        payload->setOptions(opt);
        sendNextPacketWithADRACKReq = false;
    }

    auto loraTag = pkt->addTagIfAbsent<LoRaTag>();
    loraTag->setBandwidth(getBW());
    loraTag->setCenterFrequency(getCF());
    loraTag->setSpreadFactor(getSF());
    loraTag->setCodeRendundance(getCR());
    loraTag->setPower(mW(math::dBmW2mW(getTP())));

    pkt->insertAtBack(payload);
    send(pkt, "socketOut");

    // ADR counters
    if (evaluateADRinNode) {
        ADR_ACK_CNT++;
        if (ADR_ACK_CNT == ADR_ACK_LIMIT)
            sendNextPacketWithADRACKReq = true;
        if (ADR_ACK_CNT >= ADR_ACK_LIMIT + ADR_ACK_DELAY) {
            ADR_ACK_CNT = 0;
            increaseSFIfPossible();
        }
    }

    emit(LoRa_AppPacketSent, getSF());
    sfVector.record(getSF());
    tpVector.record(getTP());
}

// --- LoRa Radio getter/setter wrappers ---
void SimpleLoRaSensorApp::setSF(int SF) { loRaRadio->loRaSF = SF; }
int  SimpleLoRaSensorApp::getSF() const { return loRaRadio->loRaSF; }

void SimpleLoRaSensorApp::setTP(int TP) { loRaRadio->loRaTP = TP; }
double SimpleLoRaSensorApp::getTP() const { return loRaRadio->loRaTP; }

void SimpleLoRaSensorApp::setCR(int CR) { loRaRadio->loRaCR = CR; }
int  SimpleLoRaSensorApp::getCR() const { return loRaRadio->loRaCR; }

void SimpleLoRaSensorApp::setCF(units::values::Hz CF) { loRaRadio->loRaCF = CF; }
units::values::Hz SimpleLoRaSensorApp::getCF() const { return loRaRadio->loRaCF; }

void SimpleLoRaSensorApp::setBW(units::values::Hz BW) { loRaRadio->loRaBW = BW; }
units::values::Hz SimpleLoRaSensorApp::getBW() const { return loRaRadio->loRaBW; }

void SimpleLoRaSensorApp::increaseSFIfPossible()
{
    if (getSF() < 12)
        setSF(getSF() + 1);
}

SimpleLoRaSensorApp::~SimpleLoRaSensorApp()
{
    cancelAndDelete(scheduler);
    cancelAndDelete(sendMeasurements);
}

void SimpleLoRaSensorApp::finish()
{
    cModule *host = getContainingNode(this);
    StationaryMobility *mobility = check_and_cast<StationaryMobility *>(host->getSubmodule("mobility"));
    Coord coord = mobility->getCurrentPosition();
    recordScalar("positionX", coord.x);
    recordScalar("positionY", coord.y);
    recordScalar("finalTP", getTP());
    recordScalar("finalSF", getSF());
    recordScalar("sentPackets", sentPackets);
    recordScalar("receivedADRCommands", receivedADRCommands);
}

double SimpleLoRaSensorApp::genTemperature() {
    double hrs = simTime().dbl() / 3600.0;
    return baseTemp + ampTemp * sin(2 * M_PI * (hrs / 24.0)) + normal(0, 0.2);
}

double SimpleLoRaSensorApp::genHumidity() {
    double hrs = simTime().dbl() / 3600.0;
    return baseHum + ampHum * sin(2 * M_PI * (hrs / 24.0)) + normal(0, 0.5);
}

double SimpleLoRaSensorApp::genNO2() {
    double hrs = simTime().dbl() / 3600.0;
    return baseNO2 + ampNO2 * (0.5 + 0.5 * sin(2 * M_PI * (hrs / 12.0))) + normal(0, 0.1);
}

bool SimpleLoRaSensorApp::handleOperationStage(inet::LifecycleOperation *operation, inet::IDoneCallback *doneCallback)
{
    Enter_Method_Silent();
    throw cRuntimeError("Unsupported lifecycle operation '%s'", operation->getClassName());
    return true;
}


} // namespace flora
