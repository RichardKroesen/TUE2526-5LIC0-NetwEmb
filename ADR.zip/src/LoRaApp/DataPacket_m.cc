//
// Generated file, do not edit! Created by opp_msgtool 6.0 from LoRaApp/DataPacket.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include <type_traits>
#include "DataPacket_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp

namespace flora {

Register_Enum(flora::SensorBitmap, (flora::SensorBitmap::SB_NONE, flora::SensorBitmap::SB_TEMPERATURE, flora::SensorBitmap::SB_NO2, flora::SensorBitmap::SB_HUMIDITY, flora::SensorBitmap::SB_TEMP_HUM, flora::SensorBitmap::SB_COUNTER));

Register_Class(LoRaSensorPacket)

LoRaSensorPacket::LoRaSensorPacket(const char *name) : ::omnetpp::cPacket(name)
{
}

LoRaSensorPacket::LoRaSensorPacket(const LoRaSensorPacket& other) : ::omnetpp::cPacket(other)
{
    copy(other);
}

LoRaSensorPacket::~LoRaSensorPacket()
{
    delete [] this->counterData;
}

LoRaSensorPacket& LoRaSensorPacket::operator=(const LoRaSensorPacket& other)
{
    if (this == &other) return *this;
    ::omnetpp::cPacket::operator=(other);
    copy(other);
    return *this;
}

void LoRaSensorPacket::copy(const LoRaSensorPacket& other)
{
    this->bitmap = other.bitmap;
    this->nodeId = other.nodeId;
    this->createdAt = other.createdAt;
    this->temperature = other.temperature;
    this->no2 = other.no2;
    this->humidity = other.humidity;
    this->counter = other.counter;
    delete [] this->counterData;
    this->counterData = (other.counterData_arraysize==0) ? nullptr : new char[other.counterData_arraysize];
    counterData_arraysize = other.counterData_arraysize;
    for (size_t i = 0; i < counterData_arraysize; i++) {
        this->counterData[i] = other.counterData[i];
    }
}

void LoRaSensorPacket::parsimPack(omnetpp::cCommBuffer *b) const
{
    ::omnetpp::cPacket::parsimPack(b);
    doParsimPacking(b,this->bitmap);
    doParsimPacking(b,this->nodeId);
    doParsimPacking(b,this->createdAt);
    doParsimPacking(b,this->temperature);
    doParsimPacking(b,this->no2);
    doParsimPacking(b,this->humidity);
    doParsimPacking(b,this->counter);
    b->pack(counterData_arraysize);
    doParsimArrayPacking(b,this->counterData,counterData_arraysize);
}

void LoRaSensorPacket::parsimUnpack(omnetpp::cCommBuffer *b)
{
    ::omnetpp::cPacket::parsimUnpack(b);
    doParsimUnpacking(b,this->bitmap);
    doParsimUnpacking(b,this->nodeId);
    doParsimUnpacking(b,this->createdAt);
    doParsimUnpacking(b,this->temperature);
    doParsimUnpacking(b,this->no2);
    doParsimUnpacking(b,this->humidity);
    doParsimUnpacking(b,this->counter);
    delete [] this->counterData;
    b->unpack(counterData_arraysize);
    if (counterData_arraysize == 0) {
        this->counterData = nullptr;
    } else {
        this->counterData = new char[counterData_arraysize];
        doParsimArrayUnpacking(b,this->counterData,counterData_arraysize);
    }
}

int LoRaSensorPacket::getBitmap() const
{
    return this->bitmap;
}

void LoRaSensorPacket::setBitmap(int bitmap)
{
    this->bitmap = bitmap;
}

const char * LoRaSensorPacket::getNodeId() const
{
    return this->nodeId.c_str();
}

void LoRaSensorPacket::setNodeId(const char * nodeId)
{
    this->nodeId = nodeId;
}

::omnetpp::simtime_t LoRaSensorPacket::getCreatedAt() const
{
    return this->createdAt;
}

void LoRaSensorPacket::setCreatedAt(::omnetpp::simtime_t createdAt)
{
    this->createdAt = createdAt;
}

double LoRaSensorPacket::getTemperature() const
{
    return this->temperature;
}

void LoRaSensorPacket::setTemperature(double temperature)
{
    this->temperature = temperature;
}

double LoRaSensorPacket::getNo2() const
{
    return this->no2;
}

void LoRaSensorPacket::setNo2(double no2)
{
    this->no2 = no2;
}

double LoRaSensorPacket::getHumidity() const
{
    return this->humidity;
}

void LoRaSensorPacket::setHumidity(double humidity)
{
    this->humidity = humidity;
}

int LoRaSensorPacket::getCounter() const
{
    return this->counter;
}

void LoRaSensorPacket::setCounter(int counter)
{
    this->counter = counter;
}

size_t LoRaSensorPacket::getCounterDataArraySize() const
{
    return counterData_arraysize;
}

char LoRaSensorPacket::getCounterData(size_t k) const
{
    if (k >= counterData_arraysize) throw omnetpp::cRuntimeError("Array of size %lu indexed by %lu", (unsigned long)counterData_arraysize, (unsigned long)k);
    return this->counterData[k];
}

void LoRaSensorPacket::setCounterDataArraySize(size_t newSize)
{
    char *counterData2 = (newSize==0) ? nullptr : new char[newSize];
    size_t minSize = counterData_arraysize < newSize ? counterData_arraysize : newSize;
    for (size_t i = 0; i < minSize; i++)
        counterData2[i] = this->counterData[i];
    for (size_t i = minSize; i < newSize; i++)
        counterData2[i] = 0;
    delete [] this->counterData;
    this->counterData = counterData2;
    counterData_arraysize = newSize;
}

void LoRaSensorPacket::setCounterData(size_t k, char counterData)
{
    if (k >= counterData_arraysize) throw omnetpp::cRuntimeError("Array of size %lu indexed by %lu", (unsigned long)counterData_arraysize, (unsigned long)k);
    this->counterData[k] = counterData;
}

void LoRaSensorPacket::insertCounterData(size_t k, char counterData)
{
    if (k > counterData_arraysize) throw omnetpp::cRuntimeError("Array of size %lu indexed by %lu", (unsigned long)counterData_arraysize, (unsigned long)k);
    size_t newSize = counterData_arraysize + 1;
    char *counterData2 = new char[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        counterData2[i] = this->counterData[i];
    counterData2[k] = counterData;
    for (i = k + 1; i < newSize; i++)
        counterData2[i] = this->counterData[i-1];
    delete [] this->counterData;
    this->counterData = counterData2;
    counterData_arraysize = newSize;
}

void LoRaSensorPacket::appendCounterData(char counterData)
{
    insertCounterData(counterData_arraysize, counterData);
}

void LoRaSensorPacket::eraseCounterData(size_t k)
{
    if (k >= counterData_arraysize) throw omnetpp::cRuntimeError("Array of size %lu indexed by %lu", (unsigned long)counterData_arraysize, (unsigned long)k);
    size_t newSize = counterData_arraysize - 1;
    char *counterData2 = (newSize == 0) ? nullptr : new char[newSize];
    size_t i;
    for (i = 0; i < k; i++)
        counterData2[i] = this->counterData[i];
    for (i = k; i < newSize; i++)
        counterData2[i] = this->counterData[i+1];
    delete [] this->counterData;
    this->counterData = counterData2;
    counterData_arraysize = newSize;
}

class LoRaSensorPacketDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertyNames;
    enum FieldConstants {
        FIELD_bitmap,
        FIELD_nodeId,
        FIELD_createdAt,
        FIELD_temperature,
        FIELD_no2,
        FIELD_humidity,
        FIELD_counter,
        FIELD_counterData,
    };
  public:
    LoRaSensorPacketDescriptor();
    virtual ~LoRaSensorPacketDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyName) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyName) const override;
    virtual int getFieldArraySize(omnetpp::any_ptr object, int field) const override;
    virtual void setFieldArraySize(omnetpp::any_ptr object, int field, int size) const override;

    virtual const char *getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const override;
    virtual std::string getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const override;
    virtual omnetpp::cValue getFieldValue(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual omnetpp::any_ptr getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const override;
    virtual void setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const override;
};

Register_ClassDescriptor(LoRaSensorPacketDescriptor)

LoRaSensorPacketDescriptor::LoRaSensorPacketDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(flora::LoRaSensorPacket)), "omnetpp::cPacket")
{
    propertyNames = nullptr;
}

LoRaSensorPacketDescriptor::~LoRaSensorPacketDescriptor()
{
    delete[] propertyNames;
}

bool LoRaSensorPacketDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<LoRaSensorPacket *>(obj)!=nullptr;
}

const char **LoRaSensorPacketDescriptor::getPropertyNames() const
{
    if (!propertyNames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
        const char **baseNames = base ? base->getPropertyNames() : nullptr;
        propertyNames = mergeLists(baseNames, names);
    }
    return propertyNames;
}

const char *LoRaSensorPacketDescriptor::getProperty(const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? base->getProperty(propertyName) : nullptr;
}

int LoRaSensorPacketDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    return base ? 8+base->getFieldCount() : 8;
}

unsigned int LoRaSensorPacketDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeFlags(field);
        field -= base->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_bitmap
        FD_ISEDITABLE,    // FIELD_nodeId
        FD_ISEDITABLE,    // FIELD_createdAt
        FD_ISEDITABLE,    // FIELD_temperature
        FD_ISEDITABLE,    // FIELD_no2
        FD_ISEDITABLE,    // FIELD_humidity
        FD_ISEDITABLE,    // FIELD_counter
        FD_ISARRAY | FD_ISEDITABLE | FD_ISRESIZABLE,    // FIELD_counterData
    };
    return (field >= 0 && field < 8) ? fieldTypeFlags[field] : 0;
}

const char *LoRaSensorPacketDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldName(field);
        field -= base->getFieldCount();
    }
    static const char *fieldNames[] = {
        "bitmap",
        "nodeId",
        "createdAt",
        "temperature",
        "no2",
        "humidity",
        "counter",
        "counterData",
    };
    return (field >= 0 && field < 8) ? fieldNames[field] : nullptr;
}

int LoRaSensorPacketDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    int baseIndex = base ? base->getFieldCount() : 0;
    if (strcmp(fieldName, "bitmap") == 0) return baseIndex + 0;
    if (strcmp(fieldName, "nodeId") == 0) return baseIndex + 1;
    if (strcmp(fieldName, "createdAt") == 0) return baseIndex + 2;
    if (strcmp(fieldName, "temperature") == 0) return baseIndex + 3;
    if (strcmp(fieldName, "no2") == 0) return baseIndex + 4;
    if (strcmp(fieldName, "humidity") == 0) return baseIndex + 5;
    if (strcmp(fieldName, "counter") == 0) return baseIndex + 6;
    if (strcmp(fieldName, "counterData") == 0) return baseIndex + 7;
    return base ? base->findField(fieldName) : -1;
}

const char *LoRaSensorPacketDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldTypeString(field);
        field -= base->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_bitmap
        "string",    // FIELD_nodeId
        "omnetpp::simtime_t",    // FIELD_createdAt
        "double",    // FIELD_temperature
        "double",    // FIELD_no2
        "double",    // FIELD_humidity
        "int",    // FIELD_counter
        "char",    // FIELD_counterData
    };
    return (field >= 0 && field < 8) ? fieldTypeStrings[field] : nullptr;
}

const char **LoRaSensorPacketDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldPropertyNames(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_bitmap: {
            static const char *names[] = { "enum", "enum",  nullptr };
            return names;
        }
        default: return nullptr;
    }
}

const char *LoRaSensorPacketDescriptor::getFieldProperty(int field, const char *propertyName) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldProperty(field, propertyName);
        field -= base->getFieldCount();
    }
    switch (field) {
        case FIELD_bitmap:
            if (!strcmp(propertyName, "enum")) return "SensorBitmap";
            if (!strcmp(propertyName, "enum")) return "flora::SensorBitmap";
            return nullptr;
        default: return nullptr;
    }
}

int LoRaSensorPacketDescriptor::getFieldArraySize(omnetpp::any_ptr object, int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldArraySize(object, field);
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_counterData: return pp->getCounterDataArraySize();
        default: return 0;
    }
}

void LoRaSensorPacketDescriptor::setFieldArraySize(omnetpp::any_ptr object, int field, int size) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldArraySize(object, field, size);
            return;
        }
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_counterData: pp->setCounterDataArraySize(size); break;
        default: throw omnetpp::cRuntimeError("Cannot set array size of field %d of class 'LoRaSensorPacket'", field);
    }
}

const char *LoRaSensorPacketDescriptor::getFieldDynamicTypeString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldDynamicTypeString(object,field,i);
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string LoRaSensorPacketDescriptor::getFieldValueAsString(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValueAsString(object,field,i);
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_bitmap: return enum2string(pp->getBitmap(), "flora::SensorBitmap");
        case FIELD_nodeId: return oppstring2string(pp->getNodeId());
        case FIELD_createdAt: return simtime2string(pp->getCreatedAt());
        case FIELD_temperature: return double2string(pp->getTemperature());
        case FIELD_no2: return double2string(pp->getNo2());
        case FIELD_humidity: return double2string(pp->getHumidity());
        case FIELD_counter: return long2string(pp->getCounter());
        case FIELD_counterData: return long2string(pp->getCounterData(i));
        default: return "";
    }
}

void LoRaSensorPacketDescriptor::setFieldValueAsString(omnetpp::any_ptr object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValueAsString(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_bitmap: pp->setBitmap((flora::SensorBitmap)string2enum(value, "flora::SensorBitmap")); break;
        case FIELD_nodeId: pp->setNodeId((value)); break;
        case FIELD_createdAt: pp->setCreatedAt(string2simtime(value)); break;
        case FIELD_temperature: pp->setTemperature(string2double(value)); break;
        case FIELD_no2: pp->setNo2(string2double(value)); break;
        case FIELD_humidity: pp->setHumidity(string2double(value)); break;
        case FIELD_counter: pp->setCounter(string2long(value)); break;
        case FIELD_counterData: pp->setCounterData(i,string2long(value)); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LoRaSensorPacket'", field);
    }
}

omnetpp::cValue LoRaSensorPacketDescriptor::getFieldValue(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldValue(object,field,i);
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_bitmap: return pp->getBitmap();
        case FIELD_nodeId: return pp->getNodeId();
        case FIELD_createdAt: return pp->getCreatedAt().dbl();
        case FIELD_temperature: return pp->getTemperature();
        case FIELD_no2: return pp->getNo2();
        case FIELD_humidity: return pp->getHumidity();
        case FIELD_counter: return pp->getCounter();
        case FIELD_counterData: return pp->getCounterData(i);
        default: throw omnetpp::cRuntimeError("Cannot return field %d of class 'LoRaSensorPacket' as cValue -- field index out of range?", field);
    }
}

void LoRaSensorPacketDescriptor::setFieldValue(omnetpp::any_ptr object, int field, int i, const omnetpp::cValue& value) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldValue(object, field, i, value);
            return;
        }
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        case FIELD_bitmap: pp->setBitmap((flora::SensorBitmap)value.intValue()); break;
        case FIELD_nodeId: pp->setNodeId(value.stringValue()); break;
        case FIELD_createdAt: pp->setCreatedAt(value.doubleValue()); break;
        case FIELD_temperature: pp->setTemperature(value.doubleValue()); break;
        case FIELD_no2: pp->setNo2(value.doubleValue()); break;
        case FIELD_humidity: pp->setHumidity(value.doubleValue()); break;
        case FIELD_counter: pp->setCounter(omnetpp::checked_int_cast<int>(value.intValue())); break;
        case FIELD_counterData: pp->setCounterData(i,omnetpp::checked_int_cast<char>(value.intValue())); break;
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LoRaSensorPacket'", field);
    }
}

const char *LoRaSensorPacketDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructName(field);
        field -= base->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

omnetpp::any_ptr LoRaSensorPacketDescriptor::getFieldStructValuePointer(omnetpp::any_ptr object, int field, int i) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount())
            return base->getFieldStructValuePointer(object, field, i);
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        default: return omnetpp::any_ptr(nullptr);
    }
}

void LoRaSensorPacketDescriptor::setFieldStructValuePointer(omnetpp::any_ptr object, int field, int i, omnetpp::any_ptr ptr) const
{
    omnetpp::cClassDescriptor *base = getBaseClassDescriptor();
    if (base) {
        if (field < base->getFieldCount()){
            base->setFieldStructValuePointer(object, field, i, ptr);
            return;
        }
        field -= base->getFieldCount();
    }
    LoRaSensorPacket *pp = omnetpp::fromAnyPtr<LoRaSensorPacket>(object); (void)pp;
    switch (field) {
        default: throw omnetpp::cRuntimeError("Cannot set field %d of class 'LoRaSensorPacket'", field);
    }
}

}  // namespace flora

namespace omnetpp {

}  // namespace omnetpp

