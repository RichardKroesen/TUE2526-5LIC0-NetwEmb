#pragma once
#include <string>

namespace flora {

struct LoRaSensorPacket {
    int bitmap = 0;
    std::string nodeId;
    double temperature = NAN;
    double no2 = NAN;
    double humidity = NAN;
    int counter = 0;
};

} // namespace flora
