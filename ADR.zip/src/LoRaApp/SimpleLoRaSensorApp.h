#ifndef __LORA_OMNET_SIMPLELORASENSORAPP_H_
#define __LORA_OMNET_SIMPLELORASENSORAPP_H_

#include <omnetpp.h>
#include "inet/common/lifecycle/ILifecycle.h"
#include "inet/common/lifecycle/NodeStatus.h"
#include "inet/common/ModuleAccess.h"
#include "inet/common/lifecycle/LifecycleOperation.h"
#include "inet/common/packet/Packet.h"
#include "inet/common/Units.h"
#include "inet/common/INETDefs.h"

#include "LoRaAppPacket_m.h"
#include "LoRa/LoRaMacControlInfo_m.h"
#include "LoRa/LoRaRadio.h"

#include <array>
#include <utility>
#include <cmath>

using namespace omnetpp;
using namespace inet;

namespace flora {

/**
 * Sensor identifiers
 */
enum SensorID {
    SID_TEMPERATURE = 0,
    SID_NO2        = 1,
    SID_HUMIDITY   = 2,
    SID_COUNTER    = 3,
    SID_COUNT      = 4
};

struct Sensor {
    SensorID id;       // which sensor this is
    double interval;   // sampling interval
    long counter;      // used for count-only sensors
    simtime_t nextDue; // next scheduled sampling time
    bool countOnly;    // whether this sensor only counts
};


/**
 * Per-sensor runtime information
 */
struct SensorInfo {
    SensorID id = SID_TEMPERATURE;
    double interval = 0;      // seconds
    bool isCounter = false;
    double lastValue = NAN;
    int counter = 0;
    simtime_t nextDue = SIMTIME_MAX;
};

/**
 * SimpleLoRaSensorApp
 * - Sensor aggregation + LoRa packet sending + ADR handling
 */
class SimpleLoRaSensorApp : public cSimpleModule, public ILifecycle
{
  protected:
    // OMNeT++ lifecycle
    void initialize(int stage) override;
    void handleMessage(cMessage *msg) override;
    void finish() override;
    int numInitStages() const override { return NUM_INIT_STAGES; }

    // ILifecycle
    bool handleOperationStage(LifecycleOperation *operation, IDoneCallback *doneCallback) override;

    // Lower layer helpers
    void handleMessageFromLowerLayer(cMessage *msg);

    // Sensor scheduling
    void initSensor(SensorID id, double interval, bool isCounter);
    simtime_t earliestNextDue() const;
    void scheduleNext();
    void sampleAndSendIfDue();
    double genTemperature();
    double genHumidity();
    double genNO2();

    // Deployment
    std::pair<double,double> generateUniformCircleCoordinates(double radius, double gatewayX, double gatewayY);

    // LoRa / ADR
    void increaseSFIfPossible();

    // LoRa radio parameters
    void setSF(int SF);
    int getSF() const;
    void setTP(int TP);
    double getTP() const;
    void setCR(int CR);
    int getCR() const;
    void setCF(units::values::Hz CF);
    units::values::Hz getCF() const;
    void setBW(units::values::Hz BW);
    units::values::Hz getBW() const;

  protected:
    // --- Sensor parameters ---
    double jitterFrac = 0.0;

    double baseTemp = 20.0;
    double ampTemp  = 0.0;
    double baseHum  = 50.0;
    double ampHum   = 0.0;
    double baseNO2  = 0.0;
    double ampNO2   = 0.0;

    int basePayloadBytes = 0;
    int counterPayloadBytes = 4;

    std::vector<Sensor> sensors;
    cMessage *scheduler = nullptr;
    cMessage *sendMeasurements = nullptr;
    int numberOfPacketsToSend = 0;

    // --- LoRa / ADR state ---
    LoRaRadio *loRaRadio = nullptr;
    bool evaluateADRinNode = false;
    int ADR_ACK_CNT = 0;
    int ADR_ACK_LIMIT = 64;
    int ADR_ACK_DELAY = 32;
    bool sendNextPacketWithADRACKReq = false;

    // --- Bookkeeping ---
    int sentPackets = 0;
    int receivedADRCommands = 0;

    cOutVector sfVector;
    cOutVector tpVector;

    // Signals
    simsignal_t LoRa_AppPacketSent;
    simsignal_t sigTemp;
    simsignal_t sigHum;
    simsignal_t sigNO2;
    simsignal_t sigCounter;
    simsignal_t sigSF;
    simsignal_t sigTP;

  public:
    SimpleLoRaSensorApp() = default;
    virtual ~SimpleLoRaSensorApp() override;
};

} // namespace flora

#endif // __LORA_OMNET_SIMPLELORASENSORAPP_H_
