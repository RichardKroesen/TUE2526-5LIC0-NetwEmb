import os
import pandas as pd
import re
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

csv_file = "results/Untitled.csv"

# --- Simulation area size (from .ini) ---
x_max = 10000  # replace with actual from your ini
y_max = 9000   # replace with actual from your ini

# --- Create folder for plots ---
plots_dir = "plots"
os.makedirs(plots_dir, exist_ok=True)

# --- Load CSV ---
df = pd.read_csv(csv_file, header=None, dtype=str)
print(f"Total rows in CSV: {df.shape[0]}")

# --- Extract node index function ---
def extract_node(module_str):
    match = re.search(r'loRaNodes\[(\d+)\]', str(module_str), re.IGNORECASE)
    return int(match.group(1)) if match else None

# ===============================
# --- PARAMETERS (X, Y, SF, TP, etc.) ---
# ===============================
param_cols = ['initialX', 'initialY', 'initialLoRaSF', 'initialLoRaTP', 'positionsX', 'positionY', 'finalTP', 'finalSF', 'sentPackets', 'receivedADR']  # add more if needed
positions_df = df[(df[1]=='param') & (df[3].isin(param_cols))].copy()
positions_df['node'] = positions_df[2].apply(extract_node)
positions_df['value'] = pd.to_numeric(positions_df[6].str.replace('m','', regex=False), errors='coerce')
positions_df = positions_df.dropna(subset=['node','value'])
positions_df = positions_df.groupby(['node', 3])['value'].first().reset_index()
positions_df = positions_df.pivot(index='node', columns=3, values='value').reset_index()

print("\nPositions & param DataFrame (first 10 nodes):")
print(positions_df.head(10))

# ===============================
# --- SCALAR METRICS ---
# ===============================
scalar_df = df[df[1] == 'scalar'].copy()
scalar_df['node'] = scalar_df[2].apply(extract_node)

# Robust extraction: first numeric value in columns 4..16
def first_numeric_value(row):
    for col in range(4, 17):
        val = row[col]
        if pd.notna(val):
            try:
                return float(val)
            except:
                pass
    return np.nan

scalar_df['value'] = scalar_df.apply(first_numeric_value, axis=1)
scalar_df = scalar_df.dropna(subset=['node','value'])

# Aggregate duplicates and pivot
scalar_df = scalar_df.groupby(['node', 3])['value'].last().reset_index()
scalar_df = scalar_df.pivot(index='node', columns=3, values='value').reset_index()

print("\nPivoted scalar metrics DataFrame (first 10 nodes):")
print(scalar_df.head(10))

# ===============================
# --- MERGE POSITIONS + SCALARS ---
# ===============================
merged_df = pd.merge(positions_df, scalar_df, on='node', how='left')

print("\nMerged DataFrame (first 10 nodes):")
print(merged_df.head(10))
print(f"\nTotal nodes in merged DataFrame: {merged_df.shape[0]}")

num_nodes = merged_df.shape[0]
factor = 0.5  # adjust between 0.5 and 1.0; smaller -> fewer squares -> fewer NaNs
# --- Compute simulation bounds dynamically ---
x_min = merged_df['initialX'].min()
x_max = merged_df['initialX'].max()
y_min = merged_df['initialY'].min()
y_max = merged_df['initialY'].max()

print(f"Simulation bounds: X [{x_min}, {x_max}], Y [{y_min}, {y_max}]")

# --- Target total squares for high resolution ---
target_squares = num_nodes *10  # roughly 1 square per node
aspect_ratio = (y_max - y_min) / (x_max - x_min)  # ~0.9 for 10000x9000 area

# Compute grid size while preserving aspect ratio
grid_size_x = int(np.sqrt(target_squares / aspect_ratio))
grid_size_y = int(np.sqrt(target_squares * aspect_ratio))

# Make sure sizes are at least 1
grid_size_x = max(1, grid_size_x)
grid_size_y = max(1, grid_size_y)

print(f"Grid size: {grid_size_x} x {grid_size_y} (total {grid_size_x*grid_size_y} squares)")

# --- Compute block size dynamically ---
block_width = (x_max - x_min) / grid_size_x
block_height = (y_max - y_min) / grid_size_y

# --- Determine block index for each node, shifted by minX/minY ---
merged_df['block_x'] = ((merged_df['initialX'] - x_min) // block_width).astype(int)
merged_df['block_y'] = ((merged_df['initialY'] - y_min) // block_height).astype(int)

# Ensure indices do not exceed grid
merged_df['block_x'] = merged_df['block_x'].clip(0, grid_size_x - 1)
merged_df['block_y'] = merged_df['block_y'].clip(0, grid_size_y - 1)


# --- Helper function to create heatmap ---
def create_heatmap(df, metric, grid_x, grid_y, fill_value=np.nan):
    heatmap = np.full((grid_y, grid_x), fill_value, dtype=float)
    for y in range(grid_y):
        for x in range(grid_x):
            block_values = df[(df['block_x']==x) & (df['block_y']==y)][metric]
            if len(block_values) > 0:
                heatmap[y, x] = block_values.mean()
    return heatmap


def plot_heatmap_debug(
    heatmap, metric_name, plots_dir,
    gateways=None, nodes=None,
    x_min=0, x_max=1, y_min=0, y_max=1,
    grid_x=1, grid_y=1
):
    fig, ax = plt.subplots(figsize=(8,6))

    # --- Smooth missing values ---
    if np.isnan(heatmap).any():
        nan_mean = np.nanmean(heatmap)
        heatmap = np.where(np.isnan(heatmap), nan_mean, heatmap)

    # --- Plot heatmap ---
    im = ax.imshow(heatmap, origin='lower', cmap='viridis')
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label(metric_name)

    # --- Compute grid block size ---
    block_width = (x_max - x_min) / grid_x
    block_height = (y_max - y_min) / grid_y

    # --- Plot gateways (red X) ---
    if gateways is not None:
        for (gx, gy) in gateways:
            gw_x = int((gx - x_min) // block_width)
            gw_y = int((gy - y_min) // block_height)
            gw_x = np.clip(gw_x, 0, grid_x - 1)
            gw_y = np.clip(gw_y, 0, grid_y - 1)
            ax.scatter(gw_x, gw_y, color='red', marker='X', s=80, label='Gateway', zorder=3)
            ax.text(gw_x, gw_y + 0.25, 'GW', ha='center', va='bottom', color='white',
                    fontsize=7, fontweight='bold', zorder=4)

    # --- Plot nodes (small white dots) ---
    if nodes is not None:
        for (nx, ny) in nodes:
            node_x = int((nx - x_min) // block_width)
            node_y = int((ny - y_min) // block_height)
            node_x = np.clip(node_x, 0, grid_x - 1)
            node_y = np.clip(node_y, 0, grid_y - 1)
            ax.scatter(node_x, node_y, color='black', s=10, alpha=0.6, label='Node', zorder=2)

    # --- Labels & layout ---
    ax.set_title(f'{metric_name} Heatmap')
    ax.set_xlabel('Block X')
    ax.set_ylabel('Block Y')

    # --- Avoid duplicate legend entries ---
    handles, labels = ax.get_legend_handles_labels()
    unique = dict(zip(labels, handles))
    ax.legend(unique.values(), unique.keys(), loc='upper right')

    plt.tight_layout()

    filename = metric_name.lower().replace(' ','_').replace(':','_') + "_heatmap.png"
    plt.savefig(os.path.join(plots_dir, filename))
    plt.close()



# --- Node count heatmap ---
node_count_heatmap = np.zeros((grid_size_y, grid_size_x))
for y in range(grid_size_y):
    for x in range(grid_size_x):
        node_count_heatmap[y,x] = len(merged_df[(merged_df['block_x']==x) & (merged_df['block_y']==y)])

plt.figure(figsize=(8,6))
plt.imshow(node_count_heatmap, origin='lower', cmap='viridis')
plt.colorbar(label='Number of nodes')
plt.title('Node Count Heatmap')
plt.xlabel('Block X')
plt.ylabel('Block Y')
plt.tight_layout()
plt.savefig(os.path.join(plots_dir, "node_count_heatmap.png"))
plt.close()

# --- Automatically generate heatmaps for all param & scalar columns ---
exclude_cols = ['node', 'block_x', 'block_y']
metric_cols = [c for c in merged_df.columns if c not in exclude_cols]

# for col in metric_cols:
#     heatmap = create_heatmap(merged_df, col, grid_size_x, grid_size_y)
    
#     plt.figure(figsize=(8,6))
#     plt.imshow(heatmap, origin='lower', cmap='hot')
#     plt.colorbar(label=col)
#     plt.title(f'{col} Heatmap')
#     plt.xlabel('Block X')
#     plt.ylabel('Block Y')
#     plt.tight_layout()
    
#     filename = col.lower().replace(' ','_').replace(':','_') + "_heatmap.png"
#     plt.savefig(os.path.join(plots_dir, filename))
#     plt.close()

# Node positions
nodes = list(zip(merged_df['initialX'], merged_df['initialY']))

# Gateway positions (example for 3×3 grid)
gateways = [
    (0, 0), (0, 2000), (0, 4000),
    (2000, 0), (2000, 2000), (2000, 4000),
    (4000, 0), (4000, 2000), (4000, 4000)
]

for col in metric_cols:
    heatmap = create_heatmap(merged_df, col, grid_size_x, grid_size_y)
    plot_heatmap_debug(
        heatmap, col, plots_dir,
        gateways=gateways,
        nodes=nodes,
        x_min=x_min, x_max=x_max,
        y_min=y_min, y_max=y_max,
        grid_x=grid_size_x, grid_y=grid_size_y
    )


print(f"All heatmaps saved in folder: {plots_dir}")
