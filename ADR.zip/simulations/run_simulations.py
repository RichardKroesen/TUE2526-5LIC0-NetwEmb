import os
import shutil
import subprocess
import concurrent
from itertools import product
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

OMNET_EXECUTABLE = "/home/lars/Documents/opp_env/omnetpp-6.0.3/bin/opp_run" # or "./run" depending on your setup
BASE_INI = "omnetpp_base.ini"
RESULTS_DIR = "results"
SIM_SCRIPT = "LoRaNetworkTest"  # your actual simulation name

# PARAMETER RANGES
SPREAD_FACTORS = [7]#[7, 8, 9, 10, 11, 12]
TRANSMIT_POWERS = [-5]#[-5, -2, 1, 4, 7, 10]
NODE_COUNTS = [300]#[300, 500]
GATEWAY_COUNTS = [1]#[1, 2, 4]

# HOW MANY SIMULATIONS TO RUN IN PARALLEL
MAX_PARALLEL = 1

# Example list of NED directories (absolute or relative)
NED_DIRS = [
    "/home/lars/Documents/opp_env/omnetpp-6.0.3/src",    # for core OMNeT++ NEDs
    "/home/lars/Documents/opp_env/inet-4.4.0/src",       # for INET framework NEDs
    "/home/lars/Documents/opp_env/flora-1.1.0/src",      # for FLORA NEDs
    ".",  # if your project’s own NED files are in your project folder
]



def generate_ini(sf, tp, nodes, gateways):
    with open(BASE_INI, "r") as f:
        base_ini = f.read()

    updated_ini = base_ini
    updated_ini += f"\n**.numberOfNodes = {nodes}"
    updated_ini += f"\n**.numberOfGateways = {gateways}"
    updated_ini += f"\n**.loRaNodes[*].**initialLoRaSF = {sf}"
    updated_ini += f"\n**.loRaNodes[*].**initialLoRaTP = {tp}dBm"

    return updated_ini


def run_simulation(sf, tp, nodes, gateways):
    sim_name = f"SF{sf}_TP{tp}_N{nodes}_GW{gateways}"
    out_dir = os.path.join(RESULTS_DIR, sim_name)
    os.makedirs(out_dir, exist_ok=True)

    # Generate full ini content with base + overrides
    full_ini_content = generate_ini(sf, tp, nodes, gateways)

    # Write full ini content to a new file inside the result directory
    ini_file_path = os.path.join(out_dir, "omnetpp.ini")
    with open(ini_file_path, "w") as f:
        f.write(full_ini_content)

    print(f"▶️ Starting simulation: {sim_name}")

    try:
        result = subprocess.run(
            [
                OMNET_EXECUTABLE,
                "-u", "Cmdenv",
                "-n", ".:" + ":".join(NED_DIRS),  # using NED_DIRS list you have
                "-f", ini_file_path,
            ],
            cwd=".",
            capture_output=True,
            text=True
        )

        # Save logs
        with open(os.path.join(out_dir, "stdout.txt"), "w") as f:
            f.write(result.stdout)
        with open(os.path.join(out_dir, "stderr.txt"), "w") as f:
            f.write(result.stderr)

        if result.returncode == 0:
            print(f"✅ Finished: {sim_name}")
        else:
            print(f"❌ Error in {sim_name} — see stderr.txt")

    except Exception as e:
        print(f"❌ Exception in {sim_name}: {e}")




def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)

    # Create all combinations
    param_combinations = list(product(SPREAD_FACTORS, TRANSMIT_POWERS, NODE_COUNTS, GATEWAY_COUNTS))
    total_jobs = len(param_combinations)

    with ThreadPoolExecutor(max_workers=MAX_PARALLEL) as executor:
        # Submit all jobs
        futures = {
            executor.submit(run_simulation, sf, tp, nodes, gateways): (sf, tp, nodes, gateways)
            for sf, tp, nodes, gateways in param_combinations
        }

        # Show progress as jobs finish
        for future in tqdm(concurrent.futures.as_completed(futures), total=total_jobs, desc="Simulations"):
            try:
                future.result()
            except Exception as e:
                sf, tp, nodes, gateways = futures[future]
                print(f"❌ Failed for SF={sf}, TP={tp}, N={nodes}, GW={gateways}: {e}")


if __name__ == "__main__":
    main()
